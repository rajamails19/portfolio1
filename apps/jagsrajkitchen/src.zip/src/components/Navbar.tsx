import { useEffect, useState } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { Facebook, Instagram, Youtube, Menu, X } from "lucide-react";
import { Logo } from "./Logo";

const ORDER_URL = "https://order.toasttab.com/online/moringa-kitchen-suwanee-1039-peachtree-industrial-blvd";

export function Navbar() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  const socials = (
    <>
      <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><Facebook size={18} /></a>
      <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><Instagram size={18} /></a>
      <a href="https://google.com" target="_blank" rel="noopener noreferrer" aria-label="Google"><span style={{fontWeight:700,fontSize:16}}>G</span></a>
      <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" aria-label="TikTok"><span style={{fontWeight:700,fontSize:14}}>TT</span></a>
      <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube"><Youtube size={18} /></a>
    </>
  );

  return (
    <>
      <header className="nav">
        <button className="hamburger" onClick={() => setOpen(true)} aria-label="Open menu"><Menu /></button>
        <Logo />
        <nav className="nav-center">
          <Link to="/raja-kitchen-menu">Menu</Link>
          <Link to="/indian-cuisine">Our Story</Link>
          <a href={ORDER_URL} target="_blank" rel="noopener noreferrer">Online Order</a>
        </nav>
        <div className="nav-right">
          <div className="nav-socials">{socials}</div>
          <span className="nav-locations">Locations</span>
        </div>
      </header>

      {open && (
        <div className="mobile-overlay">
          <button className="close" onClick={() => setOpen(false)} aria-label="Close menu"><X /></button>
          <div className="m-logo"><Logo /></div>
          <nav>
            <Link to="/raja-kitchen-menu" onClick={() => setOpen(false)}>Menu</Link>
            <Link to="/indian-cuisine" onClick={() => setOpen(false)}>Our Story</Link>
            <a href={ORDER_URL} target="_blank" rel="noopener noreferrer" onClick={() => setOpen(false)}>Online Order</a>
          </nav>
          <div className="m-socials">{socials}</div>
          <span className="m-locations">Locations</span>
        </div>
      )}
    </>
  );
}
