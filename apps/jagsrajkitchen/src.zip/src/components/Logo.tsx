import { Link } from "@tanstack/react-router";

export function Logo() {
  return (
    <Link to="/" className="nav-logo">
      <span className="l1">RAJA</span>
      <span className="l2">—Kitchen—</span>
      <span className="l3">Indian bar and restaurant</span>
    </Link>
  );
}
