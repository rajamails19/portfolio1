import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";

const ORDER_URL = "https://order.toasttab.com/online/moringa-kitchen-suwanee-1039-peachtree-industrial-blvd";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Raja Kitchen — Indian Bar and Restaurant" },
      { name: "description", content: "Fine-casual Indian dining experience in Atlanta, GA." },
      { property: "og:title", content: "Raja Kitchen" },
      { property: "og:description", content: "Global • Fine Dining Experience" },
    ],
  }),
  component: Home,
});

function Home() {
  const navigate = useNavigate();
  const [first, setFirst] = useState("");
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");
  const [errs, setErrs] = useState<{ email?: boolean; msg?: boolean }>({});
  const [success, setSuccess] = useState(false);

  const submit = () => {
    const newErrs: typeof errs = {};
    if (!email.trim()) newErrs.email = true;
    if (!msg.trim()) newErrs.msg = true;
    setErrs(newErrs);
    if (Object.keys(newErrs).length === 0) {
      setSuccess(true);
      setFirst(""); setEmail(""); setMsg("");
    }
  };

  return (
    <main>
      <section className="hero">
        <div className="hero-content">
          <h1 className="hero-title">RAJA KITCHEN</h1>
          <p className="hero-sub">Global • Fine Dining Experience</p>
          <div className="hero-buttons">
            <button className="btn-white" onClick={() => navigate({ to: "/raja-kitchen-menu" })}>View Our Menu</button>
            <a className="btn-olive" href={ORDER_URL} target="_blank" rel="noopener noreferrer">Order Online</a>
          </div>
        </div>
      </section>

      <section className="journey">
        <h1>Discover Raja Kitchen's Culinary Journey</h1>
        <div className="journey-cols">
          <div>
            <h3>A Global Culinary Experience</h3>
            <p>At Raja Kitchen, we offer a fine-casual dining experience that celebrates the vibrant flavors of India blended with global influences. From bold spices to delicate presentations, our menu transforms timeless traditions into modern plates.</p>
          </div>
          <div>
            <h3>Quality Ingredients, Exceptional Taste</h3>
            <p>At Raja Kitchen, you'll never find MSG, preservatives, or artificial colors in your meal. Every dish is crafted from scratch with locally sourced produce, and freshly ground spices. From grilled-to-order proteins to handmade sauces.</p>
          </div>
        </div>
        <img className="journey-img" src="https://images.unsplash.com/photo-1552566626-52f8b828add9?w=1400" alt="Restaurant interior" />
      </section>

      <section className="contact">
        <div className="contact-bg" />
        <div className="contact-overlay" />
        <div className="contact-inner">
          <p className="contact-tag">We'd love to hear from you about your experience.</p>
          <div className="contact-card">
            <label>Your First Name</label>
            <input type="text" placeholder="Enter your first name" value={first} onChange={(e) => setFirst(e.target.value)} />

            <label>Your Email Address*</label>
            <input className={errs.email ? "error-input" : ""} type="email" placeholder="Enter your email address" value={email} onChange={(e) => setEmail(e.target.value)} />
            {errs.email && <span className="error-msg">Email is required</span>}

            <label>Your Message*</label>
            <textarea className={errs.msg ? "error-input" : ""} placeholder="Type your message here" value={msg} onChange={(e) => setMsg(e.target.value)} />
            {errs.msg && <span className="error-msg">Message is required</span>}

            <button className="submit" onClick={submit}>Submit Your Inquiry</button>
            {success && <p className="success-msg">Thank you! We'll be in touch soon.</p>}
          </div>
        </div>
      </section>
    </main>
  );
}
