import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { menuCategories, menuData } from "@/data/menu";

export const Route = createFileRoute("/raja-kitchen-menu")({
  head: () => ({
    meta: [
      { title: "Menu — Raja Kitchen" },
      { name: "description", content: "Explore the full menu at Raja Kitchen — appetizers, tandoori, biryanis, and more." },
      { property: "og:title", content: "Menu — Raja Kitchen" },
      { property: "og:description", content: "Indian flavors with global flair." },
    ],
  }),
  component: MenuPage,
});

function MenuPage() {
  const [active, setActive] = useState("soups_and_salads");
  const items = menuData[active] || [];

  return (
    <main>
      <div className="menu-header">
        <button className="menu-pill">MENU</button>
        <h1 className="menu-title">RAJA KITCHEN</h1>
        <p className="menu-subtitle">Global • Fine Dining Experience</p>
        <div className="menu-tabs">
          {menuCategories.map((c) => (
            <button
              key={c.key}
              className={`menu-tab ${active === c.key ? "active" : "inactive"}`}
              onClick={() => setActive(c.key)}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>
      <div className="menu-grid">
        {items.map((item) => (
          <div className="menu-card" key={item.name}>
            <div style={{ flex: 1 }}>
              <div className="name">{item.name}</div>
              <div className="desc">{item.desc}</div>
            </div>
            <span className="price">{item.price}</span>
          </div>
        ))}
      </div>
    </main>
  );
}
