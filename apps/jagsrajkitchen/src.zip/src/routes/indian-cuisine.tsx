import { createFileRoute, useNavigate } from "@tanstack/react-router";

const ORDER_URL = "https://order.toasttab.com/online/moringa-kitchen-suwanee-1039-peachtree-industrial-blvd";

export const Route = createFileRoute("/indian-cuisine")({
  head: () => ({
    meta: [
      { title: "Our Story — Raja Kitchen" },
      { name: "description", content: "How Raja Kitchen began — where India meets the world in Atlanta, GA." },
      { property: "og:title", content: "Our Story — Raja Kitchen" },
      { property: "og:description", content: "Where India meets the world." },
    ],
  }),
  component: StoryPage,
});

function StoryPage() {
  const navigate = useNavigate();
  return (
    <main className="story">
      <div className="story-hero">
        <h1>Our Story</h1>
        <p>Where India Meets the World</p>
      </div>

      <div className="story-cols">
        <div>
          <h3>How Raja Kitchen Began</h3>
          <p>A passion for sharing India's rich culinary heritage led to the creation of Raja Kitchen. Founded in Atlanta, Georgia, we set out to create a space where bold Indian flavors meet global sensibilities in a warm, welcoming environment.</p>
        </div>
        <div>
          <h3>Our Philosophy</h3>
          <p>We believe great food starts with integrity. Every ingredient is sourced locally when possible, every spice is freshly ground, and every dish is made from scratch. No shortcuts. No MSG. No artificial preservatives.</p>
        </div>
      </div>

      <img className="story-img" src="https://images.unsplash.com/photo-1552566626-52f8b828add9?w=1400" alt="Raja Kitchen interior" />

      <div className="story-cols">
        <div>
          <h3>The Experience</h3>
          <p>Raja Kitchen is more than a restaurant — it's a celebration. Whether you're joining us for a weekday dinner or a special occasion, our team ensures every visit feels personal and memorable.</p>
        </div>
        <div>
          <h3>Locally Rooted, Globally Inspired</h3>
          <p>Atlanta's diverse community deserves a dining destination that reflects its spirit. We draw from classic Indian recipes while embracing the culinary curiosity of our guests.</p>
        </div>
      </div>

      <div className="story-cta">
        <h2>Ready to Experience Raja Kitchen?</h2>
        <div className="story-cta-buttons">
          <button className="btn-dark" onClick={() => navigate({ to: "/raja-kitchen-menu" })}>View Our Menu</button>
          <a className="btn-olive" href={ORDER_URL} target="_blank" rel="noopener noreferrer">Order Online</a>
        </div>
      </div>
    </main>
  );
}
